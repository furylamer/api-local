CREATE TABLE IF NOT EXISTS users (
                                     id SERIAL PRIMARY KEY,
                                     telegram_id BIGINT UNIQUE NOT NULL,
                                     balance NUMERIC(10,2) DEFAULT 0,
                                     referrer_id BIGINT,
                                     current_action TEXT DEFAULT NULL,
                                     referral_code TEXT UNIQUE NOT NULL,
                                     created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
                                     FOREIGN KEY (referrer_id) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS payments (
                                        id SERIAL PRIMARY KEY,
                                        user_id BIGINT NOT NULL,
                                        amount NUMERIC(10,2) NOT NULL,
                                        bonus NUMERIC(10,2) DEFAULT 0,
                                        created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
                                        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS ai_models (
                                         id SERIAL PRIMARY KEY,
                                         user_id BIGINT NOT NULL,
                                         model_url TEXT NOT NULL,
                                         status VARCHAR(20) NOT NULL,
                                         created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
                                         FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS generated_images (
                                                id SERIAL PRIMARY KEY,
                                                model_id BIGINT NOT NULL,
                                                image_url TEXT NOT NULL,
                                                created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
                                                FOREIGN KEY (model_id) REFERENCES ai_models(id) ON DELETE CASCADE
);
