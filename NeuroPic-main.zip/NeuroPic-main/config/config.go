package config

import (
	"log"
	"os"

	"github.com/joho/godotenv"
)

// Config хранит конфигурационные параметры приложения.
type Config struct {
	Port          string
	DBHost        string
	DBPort        string
	DBUser        string
	DBPassword    string
	DBName        string
	TinkoffApiKey string
	S3Endpoint    string
	S3AccessKey   string
	S3SecretKey   string
	FalaiApiKey   string
}

// LoadConfig загружает конфигурацию из .env или переменных окружения.
func LoadConfig() *Config {
	err := godotenv.Load()
	if err != nil {
		log.Println("No .env file found, reading configuration from environment")
	}

	return &Config{
		Port:          getEnv("PORT", "8080"),
		DBHost:        getEnv("DB_HOST", "localhost"),
		DBPort:        getEnv("DB_PORT", "5432"),
		DBUser:        getEnv("DB_USER", "postgres"),
		DBPassword:    getEnv("DB_PASSWORD", "postgres"),
		DBName:        getEnv("DB_NAME", "neuropic"),
		TinkoffApiKey: getEnv("TINKOFF_API_KEY", "your_tinkoff_api_key"),
		S3Endpoint:    getEnv("S3_ENDPOINT", "your_s3_endpoint"),
		S3AccessKey:   getEnv("S3_ACCESS_KEY", "your_s3_access_key"),
		S3SecretKey:   getEnv("S3_SECRET_KEY", "your_s3_secret_key"),
		FalaiApiKey:   getEnv("FALAI_API_KEY", "your_falai_api_key"),
	}
}

func getEnv(key, fallback string) string {
	if value, exists := os.LookupEnv(key); exists {
		return value
	}
	return fallback
}
