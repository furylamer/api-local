package repository

import (
	"context"
	"database/sql"
	"fmt"
	"time"

	"github.com/AlexZhivov/NeuroPic/internal/models"
)

// PaymentRepository определяет интерфейс для работы с платежами.
type PaymentRepository interface {
	CreatePayment(ctx context.Context, payment *models.Payment) error
	CreatePaymentTx(ctx context.Context, tx *sql.Tx, payment *models.Payment) error
}

type paymentRepository struct {
	db *sql.DB
}

func NewPaymentRepository(db *sql.DB) PaymentRepository {
	return &paymentRepository{db: db}
}

func (r *paymentRepository) CreatePayment(ctx context.Context, payment *models.Payment) error {
	query := `INSERT INTO payments (user_id, amount, bonus, created_at)
	          VALUES ($1, $2, $3, $4) RETURNING id`
	err := r.db.QueryRowContext(ctx, query, payment.UserId, payment.Amount, payment.Bonus, time.Now()).Scan(&payment.Id)
	if err != nil {
		return fmt.Errorf("CreatePayment: %w", err)
	}
	return nil
}

// CreatePaymentTx создаёт запись о платеже в рамках транзакции.
func (r *paymentRepository) CreatePaymentTx(ctx context.Context, tx *sql.Tx, payment *models.Payment) error {
	query := `INSERT INTO payments (user_id, amount, bonus, created_at)
	          VALUES ($1, $2, $3, $4) RETURNING id`
	err := tx.QueryRowContext(ctx, query, payment.UserId, payment.Amount, payment.Bonus, time.Now()).Scan(&payment.Id)
	if err != nil {
		return fmt.Errorf("CreatePaymentTx: %w", err)
	}
	return nil
}
