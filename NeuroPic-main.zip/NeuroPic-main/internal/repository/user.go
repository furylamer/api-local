package repository

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"time"

	"github.com/AlexZhivov/NeuroPic/internal/models"
)

// UserRepository определяет интерфейс для работы с пользователями.
type UserRepository interface {
	CreateUser(ctx context.Context, user *models.User) error
	GetUserByTelegramId(ctx context.Context, telegramId int64) (*models.User, error)
	UpdateBalance(ctx context.Context, userId int64, amount float64) error
	UpdateBalanceTx(ctx context.Context, tx *sql.Tx, userId int64, amount float64) error
	SetCurrentAction(ctx context.Context, telegramId int64, action string) error
	ClearCurrentAction(ctx context.Context, telegramId int64) error
	GetCurrentAction(ctx context.Context, telegramId int64) (string, error)
}

type userRepository struct {
	db *sql.DB
}

func NewUserRepository(db *sql.DB) UserRepository {
	return &userRepository{db: db}
}

func (r *userRepository) CreateUser(ctx context.Context, user *models.User) error {
	query := `INSERT INTO users (telegram_id, balance, referrer_id, referral_code, created_at)
	          VALUES ($1, $2, $3, $4, $5) RETURNING id`
	err := r.db.QueryRowContext(ctx, query, user.TelegramId, user.Balance, user.ReferrerId, user.ReferralCode, time.Now()).Scan(&user.Id)
	if err != nil {
		return fmt.Errorf("CreateUser: %w", err)
	}
	return nil
}

func (r *userRepository) GetUserByTelegramId(ctx context.Context, telegramId int64) (*models.User, error) {
	query := `SELECT id, telegram_id, balance, referrer_id, current_action, referral_code, created_at FROM users WHERE telegram_id = $1`
	user := &models.User{}
	err := r.db.QueryRowContext(ctx, query, telegramId).Scan(&user.Id, &user.TelegramId, &user.Balance, &user.ReferrerId, &user.CurrentAction, &user.ReferralCode, &user.CreatedAt)
	if err == sql.ErrNoRows {
		return nil, errors.New("user not found")
	} else if err != nil {
		return nil, fmt.Errorf("GetUserByTelegramId: %w", err)
	}
	return user, nil
}

func (r *userRepository) UpdateBalance(ctx context.Context, userId int64, amount float64) error {
	query := `UPDATE users SET balance = balance + $1 WHERE id = $2`
	result, err := r.db.ExecContext(ctx, query, amount, userId)
	if err != nil {
		return fmt.Errorf("UpdateBalance: %w", err)
	}
	rows, err := result.RowsAffected()
	if err != nil || rows == 0 {
		return errors.New("UpdateBalance: no rows updated")
	}
	return nil
}

// UpdateBalanceTx обновляет баланс пользователя в рамках транзакции.
func (r *userRepository) UpdateBalanceTx(ctx context.Context, tx *sql.Tx, userId int64, amount float64) error {
	query := `UPDATE users SET balance = balance + $1 WHERE id = $2`
	result, err := tx.ExecContext(ctx, query, amount, userId)
	if err != nil {
		return fmt.Errorf("UpdateBalanceTx: %w", err)
	}
	rows, err := result.RowsAffected()
	if err != nil || rows == 0 {
		return errors.New("UpdateBalanceTx: no rows updated")
	}
	return nil
}

func (r *userRepository) SetCurrentAction(ctx context.Context, telegramId int64, action string) error {
	query := `UPDATE users SET current_action = $1 WHERE telegram_id = $2`
	_, err := r.db.ExecContext(ctx, query, action, telegramId)
	if err != nil {
		return fmt.Errorf("SetCurrentAction: %w", err)
	}
	return nil
}

func (r *userRepository) ClearCurrentAction(ctx context.Context, telegramId int64) error {
	query := `UPDATE users SET current_action = NULL WHERE telegram_id = $1`
	_, err := r.db.ExecContext(ctx, query, telegramId)
	if err != nil {
		return fmt.Errorf("ClearCurrentAction: %w", err)
	}
	return nil
}

func (r *userRepository) GetCurrentAction(ctx context.Context, telegramId int64) (string, error) {
	query := `SELECT current_action FROM users WHERE telegram_id = $1`
	var action sql.NullString
	err := r.db.QueryRowContext(ctx, query, telegramId).Scan(&action)
	if err != nil {
		return "", fmt.Errorf("GetCurrentAction: %w", err)
	}
	if action.Valid {
		return action.String, nil
	}
	return "", nil
}
