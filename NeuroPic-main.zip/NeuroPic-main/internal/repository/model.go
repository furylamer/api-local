package repository

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"time"

	"github.com/AlexZhivov/NeuroPic/internal/models"
)

// ModelRepository определяет интерфейс для работы с моделями.
type ModelRepository interface {
	CreateModel(ctx context.Context, model *models.AIModel) error
	GetModelByUser(ctx context.Context, userId int64) (*models.AIModel, error)
	UpdateModelStatus(ctx context.Context, modelId int64, status string) error
}

type modelRepository struct {
	db *sql.DB
}

func NewModelRepository(db *sql.DB) ModelRepository {
	return &modelRepository{db: db}
}

func (r *modelRepository) CreateModel(ctx context.Context, model *models.AIModel) error {
	query := `INSERT INTO ai_models (user_id, model_url, status, created_at)
	          VALUES ($1, $2, $3, $4) RETURNING id`
	err := r.db.QueryRowContext(ctx, query, model.UserId, model.ModelURL, model.Status, time.Now()).Scan(&model.Id)
	if err != nil {
		return fmt.Errorf("CreateModel: %w", err)
	}
	return nil
}

func (r *modelRepository) GetModelByUser(ctx context.Context, userId int64) (*models.AIModel, error) {
	query := `SELECT id, user_id, model_url, status, created_at FROM ai_models
	          WHERE user_id = $1 AND status = 'ready'`
	model := &models.AIModel{}
	err := r.db.QueryRowContext(ctx, query, userId).Scan(&model.Id, &model.UserId, &model.ModelURL, &model.Status, &model.CreatedAt)
	if err == sql.ErrNoRows {
		return nil, errors.New("model not found")
	} else if err != nil {
		return nil, fmt.Errorf("GetModelByUser: %w", err)
	}
	return model, nil
}

func (r *modelRepository) UpdateModelStatus(ctx context.Context, modelId int64, status string) error {
	query := `UPDATE ai_models SET status = $1 WHERE id = $2`
	result, err := r.db.ExecContext(ctx, query, status, modelId)
	if err != nil {
		return fmt.Errorf("UpdateModelStatus: %w", err)
	}
	rows, err := result.RowsAffected()
	if err != nil || rows == 0 {
		return errors.New("UpdateModelStatus: no rows updated")
	}
	return nil
}
