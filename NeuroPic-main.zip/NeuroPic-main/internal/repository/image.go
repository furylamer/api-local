package repository

import (
	"context"
	"database/sql"
	"fmt"
	"time"

	"github.com/AlexZhivov/NeuroPic/internal/models"
)

// ImageRepository определяет интерфейс для работы с изображениями.
type ImageRepository interface {
	CreateImage(ctx context.Context, image *models.GeneratedImage) error
}

type imageRepository struct {
	db *sql.DB
}

func NewImageRepository(db *sql.DB) ImageRepository {
	return &imageRepository{db: db}
}

func (r *imageRepository) CreateImage(ctx context.Context, image *models.GeneratedImage) error {
	query := `INSERT INTO generated_images (model_id, image_url, created_at)
	          VALUES ($1, $2, $3) RETURNING id`
	err := r.db.QueryRowContext(ctx, query, image.ModelId, image.ImageURL, time.Now()).Scan(&image.Id)
	if err != nil {
		return fmt.Errorf("CreateImage: %w", err)
	}
	return nil
}
