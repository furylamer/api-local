package models

import "time"

// User представляет пользователя приложения.
type User struct {
	Id            int64     `json:"id"`
	TelegramId    int64     `json:"telegram_id"`
	Balance       float64   `json:"balance"`
	ReferrerId    *int64    `json:"referrer_id,omitempty"`
	CurrentAction *string   `json:"current_action,omitempty"` // текущее состояние, например "create_model" или "topup"
	ReferralCode  string    `json:"referral_code"`            // уникальный реферальный код
	CreatedAt     time.Time `json:"created_at"`
}

// Payment представляет платёжную операцию.
type Payment struct {
	Id        int64     `json:"id"`
	UserId    int64     `json:"user_id"`
	Amount    float64   `json:"amount"`
	Bonus     float64   `json:"bonus"`
	CreatedAt time.Time `json:"created_at"`
}

// AIModel представляет обученную модель.
type AIModel struct {
	Id        int64     `json:"id"`
	UserId    int64     `json:"user_id"`
	ModelURL  string    `json:"model_url"` // URL или идентификатор модели
	Status    string    `json:"status"`    // "training", "ready", "failed"
	CreatedAt time.Time `json:"created_at"`
}

// GeneratedImage представляет сгенерированное изображение.
type GeneratedImage struct {
	Id        int64     `json:"id"`
	ModelId   int64     `json:"model_id"`
	ImageURL  string    `json:"image_url"`
	CreatedAt time.Time `json:"created_at"`
}
