package service

import (
	"context"
	"database/sql"
	"fmt"

	"github.com/AlexZhivov/NeuroPic/internal/models"
	"github.com/AlexZhivov/NeuroPic/internal/providers"
	"github.com/AlexZhivov/NeuroPic/internal/repository"
)

// PaymentService определяет интерфейс для обработки платежей.
type PaymentService interface {
	ProcessPayment(ctx context.Context, userId int64, amount float64) error
}

type paymentService struct {
	userRepo    repository.UserRepository
	paymentRepo repository.PaymentRepository
	db          *sql.DB
	tinkoff     *providers.TinkoffProvider
}

// NewPaymentService принимает дополнительный параметр db, что позволяет начинать транзакции напрямую.
func NewPaymentService(userRepo repository.UserRepository, paymentRepo repository.PaymentRepository, db *sql.DB, tinkoff *providers.TinkoffProvider) PaymentService {
	return &paymentService{
		userRepo:    userRepo,
		paymentRepo: paymentRepo,
		db:          db,
		tinkoff:     tinkoff,
	}
}

// ProcessPayment обрабатывает платёж в рамках транзакции:
// обновляет баланс, создаёт запись о платеже и (если есть) начисляет бонус рефереру.
func (s *paymentService) ProcessPayment(ctx context.Context, userId int64, amount float64) error {
	// Симуляция вызова Tinkoff API.
	if err := s.tinkoff.ProcessPayment(userId, amount); err != nil {
		return fmt.Errorf("ProcessPayment: %w", err)
	}

	// Начинаем транзакцию через s.db.
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return fmt.Errorf("ProcessPayment: begin tx: %w", err)
	}

	// Обновляем баланс пользователя в рамках транзакции.
	if err := s.userRepo.UpdateBalanceTx(ctx, tx, userId, amount); err != nil {
		tx.Rollback()
		return fmt.Errorf("ProcessPayment: update balance: %w", err)
	}

	// Создаём запись о платеже.
	payment := &models.Payment{
		UserId: userId,
		Amount: amount,
		Bonus:  0.0,
	}
	if err := s.paymentRepo.CreatePaymentTx(ctx, tx, payment); err != nil {
		tx.Rollback()
		return fmt.Errorf("ProcessPayment: create payment: %w", err)
	}

	// Начисляем бонус рефереру, если таковой существует.
	user, err := s.userRepo.GetUserByTelegramId(ctx, userId)
	if err == nil && user.ReferrerId != nil {
		bonus := amount * 0.05
		if err := s.userRepo.UpdateBalanceTx(ctx, tx, *user.ReferrerId, bonus); err != nil {
			tx.Rollback()
			return fmt.Errorf("ProcessPayment: update referrer balance: %w", err)
		}
	}

	if err := tx.Commit(); err != nil {
		return fmt.Errorf("ProcessPayment: commit tx: %w", err)
	}
	return nil
}
