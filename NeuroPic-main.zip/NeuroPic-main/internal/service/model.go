package service

import (
	"context"
	"fmt"

	"github.com/AlexZhivov/NeuroPic/internal/models"
	"github.com/AlexZhivov/NeuroPic/internal/providers"
	"github.com/AlexZhivov/NeuroPic/internal/repository"
)

type ModelService interface {
	// TrainModel – оставляем для совместимости (можно использовать дефолтный prompt)
	TrainModel(ctx context.Context, userId int64, photoPaths []string) (*models.AIModel, error)
	// TrainAndGenerate используется, когда модели ещё нет: передаём фото и промт,
	// fal.ai возвращает сгенерированное изображение и URL обученной модели.
	TrainAndGenerate(ctx context.Context, userId int64, photoPaths []string, prompt string) (string, error)
	// GenerateImage – генерация по обученной модели.
	GenerateImage(ctx context.Context, userId int64, prompt string) (string, error)
}

type modelService struct {
	modelRepo repository.ModelRepository
	imageRepo repository.ImageRepository
	falai     *providers.FalaiProvider
	s3        *providers.S3Provider
}

func NewModelService(modelRepo repository.ModelRepository, imageRepo repository.ImageRepository, falai *providers.FalaiProvider, s3 *providers.S3Provider) ModelService {
	return &modelService{
		modelRepo: modelRepo,
		imageRepo: imageRepo,
		falai:     falai,
		s3:        s3,
	}
}

// TrainModel – если требуется, можно задать дефолтный промт.
func (s *modelService) TrainModel(ctx context.Context, userId int64, photoPaths []string) (*models.AIModel, error) {
	defaultPrompt := "default prompt"
	_, err := s.TrainAndGenerate(ctx, userId, photoPaths, defaultPrompt)
	if err != nil {
		return nil, err
	}
	return s.modelRepo.GetModelByUser(ctx, userId)
}

// TrainAndGenerate обрабатывает сценарий, когда модели ещё нет.
// Он вызывает fal.ai с передачей фото и промта, получает сгенерированное изображение и URL обученной модели,
// затем удаляет исходные фото и сохраняет информацию о модели в БД.
func (s *modelService) TrainAndGenerate(ctx context.Context, userId int64, photoPaths []string, prompt string) (string, error) {
	generatedImageURL, trainedModelURL, err := s.falai.GenerateImageWithPhotos(userId, photoPaths, prompt)
	if err != nil {
		return "", fmt.Errorf("TrainAndGenerate: %w", err)
	}

	// Удаляем исходные фото из S3.
	for _, path := range photoPaths {
		if err := s.s3.DeleteFile(path); err != nil {
			// Логируем ошибку, но не прерываем процесс.
			fmt.Printf("TrainAndGenerate: failed to delete photo %s: %v\n", path, err)
		}
	}

	// Создаем запись обученной модели.
	model := &models.AIModel{
		UserId:   userId,
		ModelURL: trainedModelURL,
		Status:   "ready",
	}
	if err := s.modelRepo.CreateModel(ctx, model); err != nil {
		return "", fmt.Errorf("TrainAndGenerate: %w", err)
	}

	return generatedImageURL, nil
}

// GenerateImage использует уже обученную модель для генерации изображения по заданному промту.
func (s *modelService) GenerateImage(ctx context.Context, userId int64, prompt string) (string, error) {
	model, err := s.modelRepo.GetModelByUser(ctx, userId)
	if err != nil {
		return "", fmt.Errorf("GenerateImage: %w", err)
	}
	imageURL, err := s.falai.GenerateImage(model.ModelURL, prompt)
	if err != nil {
		return "", fmt.Errorf("GenerateImage: %w", err)
	}
	genImage := &models.GeneratedImage{
		ModelId:  model.Id,
		ImageURL: imageURL,
	}
	if err := s.imageRepo.CreateImage(ctx, genImage); err != nil {
		return "", fmt.Errorf("GenerateImage: %w", err)
	}
	return imageURL, nil
}
