package service

import (
	"context"
	"errors"
	"fmt"

	"github.com/AlexZhivov/NeuroPic/internal/models"
	"github.com/AlexZhivov/NeuroPic/internal/repository"
	"github.com/google/uuid"
)

// UserService определяет интерфейс бизнес-логики для работы с пользователями.
type UserService interface {
	RegisterUser(ctx context.Context, telegramId int64, referrerId *int64) (*models.User, error)
	GetUserByTelegramId(ctx context.Context, telegramId int64) (*models.User, error)
	SetUserAction(ctx context.Context, telegramId int64, action string) error
	ClearUserAction(ctx context.Context, telegramId int64) error
	GetUserAction(ctx context.Context, telegramId int64) (string, error)
	GetReferralLink(ctx context.Context, telegramId int64, botUsername string) (string, error)
}

type userService struct {
	userRepo repository.UserRepository
}

func NewUserService(userRepo repository.UserRepository) UserService {
	return &userService{userRepo: userRepo}
}

// RegisterUser регистрирует нового пользователя с уникальным реферальным кодом.
func (s *userService) RegisterUser(ctx context.Context, telegramId int64, referrerId *int64) (*models.User, error) {
	existing, err := s.userRepo.GetUserByTelegramId(ctx, telegramId)
	if err != nil {
		return nil, fmt.Errorf("RegisterUser: %w", err)
	}
	if existing != nil {
		return nil, errors.New("RegisterUser: user already exists")
	}
	referralCode := uuid.New().String()
	user := &models.User{
		TelegramId:   telegramId,
		Balance:      0.0,
		ReferrerId:   referrerId,
		ReferralCode: referralCode,
	}
	err = s.userRepo.CreateUser(ctx, user)
	if err != nil {
		return nil, fmt.Errorf("RegisterUser: %w", err)
	}
	return user, nil
}

func (s *userService) GetUserByTelegramId(ctx context.Context, telegramId int64) (*models.User, error) {
	return s.userRepo.GetUserByTelegramId(ctx, telegramId)
}

func (s *userService) SetUserAction(ctx context.Context, telegramId int64, action string) error {
	return s.userRepo.SetCurrentAction(ctx, telegramId, action)
}

func (s *userService) ClearUserAction(ctx context.Context, telegramId int64) error {
	return s.userRepo.ClearCurrentAction(ctx, telegramId)
}

func (s *userService) GetUserAction(ctx context.Context, telegramId int64) (string, error) {
	return s.userRepo.GetCurrentAction(ctx, telegramId)
}

// GetReferralLink возвращает ссылку для приглашения на основе реферального кода.
func (s *userService) GetReferralLink(ctx context.Context, telegramId int64, botUsername string) (string, error) {
	user, err := s.userRepo.GetUserByTelegramId(ctx, telegramId)
	if err != nil {
		return "", fmt.Errorf("GetReferralLink: %w", err)
	}
	refLink := fmt.Sprintf("https://t.me/%s?start=%s", botUsername, user.ReferralCode)
	return refLink, nil
}
