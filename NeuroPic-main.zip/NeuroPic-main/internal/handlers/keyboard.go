package handlers

// keyboard.go содержит функции построения inline‑клавиатур для Telegram.

type InlineKeyboardButton struct {
	Text         string `json:"text"`
	CallbackData string `json:"callback_data"`
}

type InlineKeyboardMarkup struct {
	InlineKeyboard [][]InlineKeyboardButton `json:"inline_keyboard"`
}

// BuildMainMenu возвращает клавиатуру главного меню.
func BuildMainMenu() *InlineKeyboardMarkup {
	buttons := [][]InlineKeyboardButton{
		{
			{Text: "Его модели", CallbackData: "menu:models"},
			{Text: "Создать модель", CallbackData: "menu:create_model"},
		},
		{
			{Text: "Проверить баланс", CallbackData: "menu:check_balance"},
			{Text: "Пополнить баланс", CallbackData: "menu:topup"},
		},
		{
			{Text: "Реферальная ссылка", CallbackData: "menu:referral"},
		},
	}
	return &InlineKeyboardMarkup{InlineKeyboard: buttons}
}

// BuildModelsMenu возвращает клавиатуру для выбора шаблона.
func BuildModelsMenu() *InlineKeyboardMarkup {
	buttons := [][]InlineKeyboardButton{
		{
			{Text: "Фото в лесу", CallbackData: "models:forest"},
			{Text: "Фото на яхте", CallbackData: "models:yacht"},
		},
		{
			{Text: "Фото на берегу моря", CallbackData: "models:seaside"},
			{Text: "Фото в подъезде", CallbackData: "models:entrance"},
		},
		{
			{Text: "Назад", CallbackData: "models:back"},
		},
	}
	return &InlineKeyboardMarkup{InlineKeyboard: buttons}
}

// BuildCreateModelMenu возвращает клавиатуру для меню создания модели.
func BuildCreateModelMenu() *InlineKeyboardMarkup {
	buttons := [][]InlineKeyboardButton{
		{
			{Text: "Пополнить баланс", CallbackData: "menu:topup"},
			{Text: "Назад", CallbackData: "menu:main"},
		},
	}
	return &InlineKeyboardMarkup{InlineKeyboard: buttons}
}

// BuildTopupMenu возвращает клавиатуру для пополнения баланса.
func BuildTopupMenu() *InlineKeyboardMarkup {
	buttons := [][]InlineKeyboardButton{
		{
			{Text: "Проверить оплату", CallbackData: "topup:check"},
			{Text: "Назад", CallbackData: "menu:main"},
		},
	}
	return &InlineKeyboardMarkup{InlineKeyboard: buttons}
}
