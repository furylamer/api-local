package handlers

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"

	"github.com/AlexZhivov/NeuroPic/internal/usecase"
	"go.uber.org/zap"
)

// Определения структур для Telegram-обновлений.
type TelegramUpdate struct {
	UpdateId      int64                  `json:"update_id"`
	Message       *TelegramMessage       `json:"message,omitempty"`
	CallbackQuery *TelegramCallbackQuery `json:"callback_query,omitempty"`
}

type TelegramMessage struct {
	MessageId int64               `json:"message_id"`
	From      TelegramUser        `json:"from"`
	Chat      TelegramChat        `json:"chat"`
	Date      int64               `json:"date"`
	Text      string              `json:"text,omitempty"`
	Photo     []TelegramPhotoSize `json:"photo,omitempty"`
}

type TelegramCallbackQuery struct {
	Id      string          `json:"id"`
	Data    string          `json:"data"`
	From    TelegramUser    `json:"from"`
	Message TelegramMessage `json:"message"`
}

type TelegramUser struct {
	Id        int64  `json:"id"`
	FirstName string `json:"first_name"`
	LastName  string `json:"last_name,omitempty"`
	Username  string `json:"username,omitempty"`
}

type TelegramChat struct {
	Id   int64  `json:"id"`
	Type string `json:"type"`
}

type TelegramPhotoSize struct {
	FileId       string `json:"file_id"`
	FileUniqueId string `json:"file_unique_id"`
	Width        int    `json:"width"`
	Height       int    `json:"height"`
	FileSize     int    `json:"file_size,omitempty"`
}

type TelegramWebhookHandler struct {
	usecase usecase.UseCase
	logger  *zap.Logger
}

func NewTelegramWebhookHandler(uc usecase.UseCase, logger *zap.Logger) *TelegramWebhookHandler {
	return &TelegramWebhookHandler{
		usecase: uc,
		logger:  logger,
	}
}

func (h *TelegramWebhookHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	body, err := io.ReadAll(r.Body)
	if err != nil {
		h.logger.Error("ServeHTTP: failed to read request body", zap.Error(err))
		http.Error(w, "Bad request", http.StatusBadRequest)
		return
	}
	var update TelegramUpdate
	err = json.Unmarshal(body, &update)
	if err != nil {
		h.logger.Error("ServeHTTP: failed to unmarshal update", zap.Error(err))
		http.Error(w, "Bad request", http.StatusBadRequest)
		return
	}
	if update.CallbackQuery != nil {
		h.handleCallbackQuery(ctx, update.CallbackQuery)
		w.WriteHeader(http.StatusOK)
		return
	}
	if update.Message != nil {
		h.handleMessage(ctx, update.Message)
		w.WriteHeader(http.StatusOK)
		return
	}
	w.WriteHeader(http.StatusOK)
}

func (h *TelegramWebhookHandler) handleMessage(ctx context.Context, msg *TelegramMessage) {
	telegramId := msg.From.Id
	chatId := msg.Chat.Id

	// Обработка команды /referral.
	if strings.HasPrefix(msg.Text, "/referral") {
		refLink, err := h.usecase.GetReferralLink(ctx, telegramId, "YourBotUsername")
		if err != nil {
			h.sendTelegramMessage(chatId, fmt.Sprintf("Ошибка: %s", err.Error()), nil)
		} else {
			h.sendTelegramMessage(chatId, fmt.Sprintf("Ваша реферальная ссылка: %s", refLink), nil)
		}
		return
	}

	// Получаем текущее действие через usecase.
	action, err := h.usecase.GetUserAction(ctx, telegramId)
	if err != nil {
		h.logger.Error("handleMessage: failed to get user action", zap.Error(err))
		action = ""
	}

	// Если ожидается обучение модели и присутствуют фотографии.
	if len(msg.Photo) > 0 && action == "create_model" {
		if len(msg.Photo) < 10 || len(msg.Photo) > 20 {
			h.sendTelegramMessage(chatId, "Пожалуйста, отправьте от 10 до 20 фотографий.", nil)
			return
		}
		photoPaths := []string{}
		uploadDir := "./uploads"
		if err := os.MkdirAll(uploadDir, os.ModePerm); err != nil {
			h.logger.Error("handleMessage: failed to create upload directory", zap.Error(err))
			h.sendTelegramMessage(chatId, "Server error", nil)
			return
		}
		for _, photo := range msg.Photo {
			filePath := filepath.Join(uploadDir, photo.FileId+".jpg")
			if _, err := os.Stat(filePath); os.IsNotExist(err) {
				f, err := os.Create(filePath)
				if err != nil {
					h.logger.Error("handleMessage: failed to create file", zap.String("file", filePath), zap.Error(err))
					continue
				}
				f.Close()
			}
			photoPaths = append(photoPaths, filePath)
		}
		_, err := h.usecase.TrainModel(ctx, telegramId, photoPaths)
		if err != nil {
			h.logger.Error("handleMessage: failed to train model", zap.Error(err))
			h.sendTelegramMessage(chatId, fmt.Sprintf("Ошибка обучения модели: %s", err.Error()), nil)
		} else {
			h.sendTelegramMessage(chatId, "Ваша модель обучена и готова к использованию!", BuildMainMenu())
		}
		_ = h.usecase.ClearUserAction(ctx, telegramId)
		return
	}

	// Если ожидается ввод суммы пополнения.
	if action == "topup" {
		amount, err := strconv.ParseFloat(strings.TrimSpace(msg.Text), 64)
		if err != nil {
			h.sendTelegramMessage(chatId, "Пожалуйста, укажите корректную сумму.", nil)
			return
		}
		paymentLink := fmt.Sprintf("http://payment.example.com?amount=%.2f", amount)
		replyText := fmt.Sprintf("Ссылка на оплату: %s", paymentLink)
		h.sendTelegramMessage(chatId, replyText, BuildTopupMenu())
		_ = h.usecase.ClearUserAction(ctx, telegramId)
		return
	}

	// Обработка команды /start.
	if strings.HasPrefix(msg.Text, "/start") {
		parts := strings.Split(msg.Text, " ")
		var referrerId *int64
		if len(parts) > 1 {
			if refId, err := strconv.ParseInt(parts[1], 10, 64); err == nil {
				referrerId = &refId
			}
		}
		_, err := h.usecase.RegisterUser(ctx, telegramId, referrerId)
		if err != nil {
			h.logger.Error("handleMessage: failed to register user", zap.Error(err))
			h.sendTelegramMessage(chatId, fmt.Sprintf("Ошибка регистрации: %s", err.Error()), nil)
		} else {
			h.sendTelegramMessage(chatId, "Добро пожаловать!", BuildMainMenu())
		}
		return
	}

	// Если нет ожидаемого действия – отправляем главное меню.
	h.sendTelegramMessage(chatId, "Пожалуйста, используйте кнопки меню.", BuildMainMenu())
}

func (h *TelegramWebhookHandler) handleCallbackQuery(ctx context.Context, cb *TelegramCallbackQuery) {
	telegramId := cb.From.Id
	chatId := cb.Message.Chat.Id
	data := cb.Data

	switch data {
	case "menu:main":
		h.sendTelegramMessage(chatId, "Главное меню", BuildMainMenu())
	case "menu:models":
		h.sendTelegramMessage(chatId, "Выберите шаблон изображения:", BuildModelsMenu())
	case "models:forest", "models:yacht", "models:seaside", "models:entrance":
		h.sendTelegramMessage(chatId, "Генерация запущена, ожидайте...", BuildModelsMenu())
	case "models:back":
		h.sendTelegramMessage(chatId, "Главное меню", BuildMainMenu())
	case "menu:create_model":
		_ = h.usecase.SetUserAction(ctx, telegramId, "create_model")
		msg := "Отправьте 10 фотографий для обучения модели.\n\nДоступны кнопки:"
		h.sendTelegramMessage(chatId, msg, BuildCreateModelMenu())
	case "menu:check_balance":
		user, err := h.usecase.GetUser(ctx, telegramId)
		if err != nil {
			h.sendTelegramMessage(chatId, fmt.Sprintf("Ошибка получения баланса: %s", err.Error()), BuildMainMenu())
		} else {
			h.sendTelegramMessage(chatId, fmt.Sprintf("Ваш баланс: %.2f", user.Balance), BuildMainMenu())
		}
	case "menu:topup":
		_ = h.usecase.SetUserAction(ctx, telegramId, "topup")
		h.sendTelegramMessage(chatId, "Напишите сумму пополнения:", nil)
	case "topup:check":
		h.sendTelegramMessage(chatId, "Ожидаем платеж...", BuildTopupMenu())
	default:
		h.sendTelegramMessage(chatId, "Неизвестная команда.", BuildMainMenu())
	}
}

func (h *TelegramWebhookHandler) sendTelegramMessage(chatId int64, text string, replyMarkup *InlineKeyboardMarkup) {
	message := map[string]interface{}{
		"chat_id": chatId,
		"text":    text,
	}
	if replyMarkup != nil {
		message["reply_markup"] = replyMarkup
	}
	h.logger.Info("sendTelegramMessage", zap.Any("message", message))
	// Здесь следует выполнять HTTP POST запрос к Telegram API.
}
