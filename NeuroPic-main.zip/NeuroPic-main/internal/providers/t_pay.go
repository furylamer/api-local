package providers

import "fmt"

// TinkoffProvider реализует вызовы платежного API Tinkoff.
type TinkoffProvider struct {
	ApiKey string
}

// NewTinkoffProvider создает новый TinkoffProvider.
func NewTinkoffProvider(apiKey string) *TinkoffProvider {
	return &TinkoffProvider{
		ApiKey: apiKey,
	}
}

// ProcessPayment симулирует обработку платежа через Tinkoff API.
func (t *TinkoffProvider) ProcessPayment(userId int64, amount float64) error {
	fmt.Printf("Processing payment for user %d of amount %.2f via Tinkoff API\n", userId, amount)
	return nil
}
