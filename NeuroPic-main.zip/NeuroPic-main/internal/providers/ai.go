package providers

import (
	"fmt"

	"github.com/google/uuid"
)

// FalaiProvider реализует вызовы для генерации изображений через fal.ai.
type FalaiProvider struct {
	ApiKey string
}

func NewFalaiProvider(apiKey string) *FalaiProvider {
	return &FalaiProvider{
		ApiKey: apiKey,
	}
}

// GenerateImageWithPhotos симулирует генерацию изображения через fal.ai с передачей фото пользователя.
// Если обученная модель отсутствует, API принимает 10-20 фото и возвращает одновременно:
// 1. URL сгенерированного изображения по промту
// 2. URL обученной модели, которую необходимо сохранить
func (f *FalaiProvider) GenerateImageWithPhotos(userId int64, photoPaths []string, prompt string) (string, string, error) {
	// Симуляция: генерируем уникальные URL-адреса
	trainedModelURL := fmt.Sprintf("http://falai/model/%s", uuid.New().String())
	generatedImageURL := fmt.Sprintf("http://falai/generated/%s.png", uuid.New().String())
	fmt.Printf("fal.ai: For user %d with prompt '%s', generated image: %s and trained model: %s\n",
		userId, prompt, generatedImageURL, trainedModelURL)
	return generatedImageURL, trainedModelURL, nil
}

// GenerateImage симулирует генерацию изображения при наличии обученной модели.
func (f *FalaiProvider) GenerateImage(modelURL, prompt string) (string, error) {
	generatedImageURL := fmt.Sprintf("http://falai/generated/%s.png", uuid.New().String())
	fmt.Printf("fal.ai: Using model %s with prompt '%s', generated image: %s\n", modelURL, prompt, generatedImageURL)
	return generatedImageURL, nil
}
