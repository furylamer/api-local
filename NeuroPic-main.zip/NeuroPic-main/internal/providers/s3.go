package providers

import "fmt"

// S3Provider реализует работу с S3-хранилищем.
type S3Provider struct {
	Endpoint  string
	AccessKey string
	SecretKey string
}

func NewS3Provider(endpoint, accessKey, secretKey string) *S3Provider {
	return &S3Provider{
		Endpoint:  endpoint,
		AccessKey: accessKey,
		SecretKey: secretKey,
	}
}

// UploadFile симулирует загрузку файла и возвращает URL.
func (s *S3Provider) UploadFile(filePath string) (string, error) {
	url := fmt.Sprintf("%s/%s", s.Endpoint, filePath)
	return url, nil
}

// DeleteFile симулирует удаление файла из S3.
func (s *S3Provider) DeleteFile(filePath string) error {
	fmt.Printf("S3: deleting file %s\n", filePath)
	return nil
}
