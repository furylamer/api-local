package usecase

import (
	"context"

	"github.com/AlexZhivov/NeuroPic/internal/models"
	"github.com/AlexZhivov/NeuroPic/internal/service"
)

type UseCase interface {
	RegisterUser(ctx context.Context, telegramId int64, referrerId *int64) (*models.User, error)
	ProcessPayment(ctx context.Context, userId int64, amount float64) error
	TrainModel(ctx context.Context, userId int64, photoPaths []string) (*models.AIModel, error)
	GenerateImage(ctx context.Context, userId int64, prompt string) (string, error)
	GetReferralLink(ctx context.Context, telegramId int64, botUsername string) (string, error)

	// Новые методы для работы с пользователями.
	GetUserAction(ctx context.Context, telegramId int64) (string, error)
	SetUserAction(ctx context.Context, telegramId int64, action string) error
	ClearUserAction(ctx context.Context, telegramId int64) error
	GetUser(ctx context.Context, telegramId int64) (*models.User, error)
}

type usecase struct {
	userService    service.UserService
	paymentService service.PaymentService
	modelService   service.ModelService
}

func NewUseCase(userService service.UserService, paymentService service.PaymentService, modelService service.ModelService) UseCase {
	return &usecase{
		userService:    userService,
		paymentService: paymentService,
		modelService:   modelService,
	}
}

func (uc *usecase) RegisterUser(ctx context.Context, telegramId int64, referrerId *int64) (*models.User, error) {
	return uc.userService.RegisterUser(ctx, telegramId, referrerId)
}

func (uc *usecase) ProcessPayment(ctx context.Context, userId int64, amount float64) error {
	return uc.paymentService.ProcessPayment(ctx, userId, amount)
}

func (uc *usecase) TrainModel(ctx context.Context, userId int64, photoPaths []string) (*models.AIModel, error) {
	return uc.modelService.TrainModel(ctx, userId, photoPaths)
}

func (uc *usecase) GenerateImage(ctx context.Context, userId int64, prompt string) (string, error) {
	return uc.modelService.GenerateImage(ctx, userId, prompt)
}

func (uc *usecase) GetReferralLink(ctx context.Context, telegramId int64, botUsername string) (string, error) {
	return uc.userService.GetReferralLink(ctx, telegramId, botUsername)
}

// Новые методы

func (uc *usecase) GetUserAction(ctx context.Context, telegramId int64) (string, error) {
	return uc.userService.GetUserAction(ctx, telegramId)
}

func (uc *usecase) SetUserAction(ctx context.Context, telegramId int64, action string) error {
	return uc.userService.SetUserAction(ctx, telegramId, action)
}

func (uc *usecase) ClearUserAction(ctx context.Context, telegramId int64) error {
	return uc.userService.ClearUserAction(ctx, telegramId)
}

func (uc *usecase) GetUser(ctx context.Context, telegramId int64) (*models.User, error) {
	return uc.userService.GetUserByTelegramId(ctx, telegramId)
}
