package main

import (
	"database/sql"
	"fmt"
	"log"
	"net/http"

	"github.com/AlexZhivov/NeuroPic/config"
	"github.com/AlexZhivov/NeuroPic/internal/handlers"
	"github.com/AlexZhivov/NeuroPic/internal/providers"
	"github.com/AlexZhivov/NeuroPic/internal/repository"
	"github.com/AlexZhivov/NeuroPic/internal/service"
	"github.com/AlexZhivov/NeuroPic/internal/usecase"
	_ "github.com/lib/pq"
	"go.uber.org/zap"
)

func main() {
	cfg := config.LoadConfig()

	logger, err := zap.NewProduction()
	if err != nil {
		log.Fatalf("failed to initialize logger: %v", err)
	}
	defer logger.Sync()

	dbInfo := fmt.Sprintf("host=%s port=%s user=%s password=%s dbname=%s sslmode=disable",
		cfg.DBHost, cfg.DBPort, cfg.DBUser, cfg.DBPassword, cfg.DBName)
	db, err := sql.Open("postgres", dbInfo)
	if err != nil {
		logger.Fatal("failed to connect to database", zap.Error(err))
	}
	defer db.Close()

	userRepo := repository.NewUserRepository(db)
	paymentRepo := repository.NewPaymentRepository(db)
	modelRepo := repository.NewModelRepository(db)
	imageRepo := repository.NewImageRepository(db)

	tinkoffProv := providers.NewTinkoffProvider(cfg.TinkoffApiKey)
	s3Prov := providers.NewS3Provider(cfg.S3Endpoint, cfg.S3AccessKey, cfg.S3SecretKey)
	falaiProv := providers.NewFalaiProvider(cfg.FalaiApiKey)

	userService := service.NewUserService(userRepo)
	paymentService := service.NewPaymentService(userRepo, paymentRepo, db, tinkoffProv)
	modelService := service.NewModelService(modelRepo, imageRepo, falaiProv, s3Prov)

	uc := usecase.NewUseCase(userService, paymentService, modelService)

	tgHandler := handlers.NewTelegramWebhookHandler(uc, logger)

	addr := fmt.Sprintf(":%s", cfg.Port)
	logger.Info("Starting Telegram webhook server", zap.String("addr", addr))
	if err := http.ListenAndServe(addr, tgHandler); err != nil {
		logger.Fatal("failed to start server", zap.Error(err))
	}
}
